#!/bin/bash
cd ../
mkdir instalacao
cd instalacao
touch teste.txt
